
#Analog power 2 and 1 imports
from ctypes import *
from dwfconstants import *
import time
import sys
#Analog sine imports
from ctypes import *
import time
from dwfconstants import *
import sys
import matplotlib.pyplot as plt
#Band Filter imports
from scipy.signal import butter, lfilter, sosfilt, sosfreqz
#Aquisition and reading imports
from ctypes import *
from dwfconstants import *
import math
import time
import matplotlib.pyplot as plt
import sys
#Maybe Add DigitalIn_Aquisition Imports

#Impedance Function Imports
from math import pi, degrees
from cmath import phase
import matplotlib.pyplot as plt


if sys.platform.startswith("win"):
    dwf = cdll.dwf
elif sys.platform.startswith("darwin"):
    dwf = cdll.LoadLibrary("/Library/Frameworks/dwf.framework/dwf")
else:
    dwf = cdll.LoadLibrary("libdwf.so")

#declaring variables
hdwf = c_int()
sts = c_byte()
IsEnabled = c_bool()
usbVoltage = c_double()
usbCurrent = c_double()
auxVoltage = c_double()
auxCurrent = c_double()
supplyVoltage = c_double()
supplyCurrent = c_double()
supplyPower = c_double()
supplyLoadPercentage = c_double()
channel1 = c_int(0)
channel2 = c_int(0)
rgdSamples = (c_double*4000)()

#print DWF version
version = create_string_buffer(16)
dwf.FDwfGetVersion(version)
print ("DWF Version:")

#opening the digilent device
print ("Opening first device")
dwf.FDwfDeviceOpen(c_int(-1), byref(hdwf))

if hdwf.value == hdwfNone.value:
    print ("failed to open device")
    quit()


# set up analog IO channel nodes
# enable positive supply
dwf.FDwfAnalogIOChannelNodeSet(hdwf, c_int(0), c_int(0), c_double(True)) 
# set voltage to 5 V
dwf.FDwfAnalogIOChannelNodeSet(hdwf, c_int(0), c_int(1), c_double(10.0)) 
# enable negative supply
dwf.FDwfAnalogIOChannelNodeSet(hdwf, c_int(1), c_int(0), c_double(True)) 
# set voltage to -5 V
dwf.FDwfAnalogIOChannelNodeSet(hdwf, c_int(1), c_int(1), c_double(-10.0)) 
# master enable
dwf.FDwfAnalogIOEnableSet(hdwf, c_int(True))

for i in range(1, 61):
    #wait 1 second between readings
    time.sleep(1)
    #fetch analogIO status from device
    if dwf.FDwfAnalogIOStatus(hdwf) == 0:
        break

    #supply monitor
    dwf.FDwfAnalogIOChannelNodeStatus(hdwf, c_int(2), c_int(0), byref(usbVoltage))
    dwf.FDwfAnalogIOChannelNodeStatus(hdwf, c_int(2), c_int(1), byref(usbCurrent))
    dwf.FDwfAnalogIOChannelNodeStatus(hdwf, c_int(3), c_int(0), byref(auxVoltage))
    dwf.FDwfAnalogIOChannelNodeStatus(hdwf, c_int(3), c_int(1), byref(auxCurrent))
    print ("USB: " + " Voltage is: "+ str(round(usbVoltage.value,3)) + "V\t" + " Current is: " + str(round(usbCurrent.value,3)) + "A")
    print ("USB: " + " AC Impedance or Resistance is: "+ str(round(usbVoltage.value/usbCurrent.value,3)) + "kOhms")
    print ("AUX: " + str(round(auxVoltage.value,3)) + "V\t" + str(round(auxCurrent.value,3)) + "A")
    break
    # in case of over-current condition the supplies are disabled
    dwf.FDwfAnalogIOEnableStatus(hdwf, byref(IsEnabled))
    if not IsEnabled:
        #re-enable supplies
        print ("Restart")
        dwf.FDwfAnalogIOEnableSet(hdwf, c_int(False)) 
        dwf.FDwfAnalogIOEnableSet(hdwf, c_int(True))

        break

print ("Preparing to read sample...")

#set up analog IO channel nodes
# enable positive supply
dwf.FDwfAnalogIOChannelNodeSet(hdwf, 0, 0, 1) 
# enable negative supply
dwf.FDwfAnalogIOChannelNodeSet(hdwf, 1, 0, 1) 
# master enable
dwf.FDwfAnalogIOEnableSet(hdwf, True) 

for i in range(1, 61):
  #wait 1 second between readings
  time.sleep(1)
  #fetch analogIO status from device
  dwf.FDwfAnalogIOStatus(hdwf)
  
  #Print total voltage and current respectively
  print ("Voltage is: "+ str(supplyVoltage.value)+ "V")
  print ("Current is: "+ str(supplyCurrent.value)+ "mA")
##  print ("AC Impedance or Resistance is "+ str(supplyVoltage.value/supplyCurrent.value) + "kOhms")

  #supply monitor
  dwf.FDwfAnalogIOChannelNodeStatus(hdwf, c_int(3), c_int(0), byref(supplyVoltage))
  dwf.FDwfAnalogIOChannelNodeStatus(hdwf, c_int(3), c_int(1), byref(supplyCurrent))
  supplyPower.value = supplyVoltage.value * supplyCurrent.value
  print ("Total supply power: " + str(supplyPower.value) + "W")

  supplyLoadPercentage.value = 100 * (supplyCurrent.value / 0.2)
  print("Load: " + str(supplyLoadPercentage.value) + "%")
  break

    
  # in case of over-current condition the supplies are disabled
dwf.FDwfAnalogIOEnableStatus(hdwf, byref(IsEnabled))
if not IsEnabled:
    #re-enable supplies
    dwf.FDwfAnalogIOEnableSet(hdwf, c_bool(False)) 
    dwf.FDwfAnalogIOEnableSet(hdwf, c_bool(True))



# Generating Sine Waveforms Signals on the two channels
print ("Generating sine wave for channel 1...")
dwf.FDwfAnalogOutNodeEnableSet(hdwf, channel1, AnalogOutNodeCarrier, c_bool(True))
dwf.FDwfAnalogOutNodeFunctionSet(hdwf, channel1, AnalogOutNodeCarrier, funcSine)
dwf.FDwfAnalogOutNodeFrequencySet(hdwf, channel1, AnalogOutNodeCarrier, c_double(10000))
dwf.FDwfAnalogOutNodeAmplitudeSet(hdwf, channel1, AnalogOutNodeCarrier, c_double(1))
dwf.FDwfAnalogOutNodeOffsetSet(hdwf, channel1, AnalogOutNodeCarrier, c_double(1.41))

print ("Generating sine wave for channel 2...")
dwf.FDwfAnalogOutNodeEnableSet(hdwf, channel2, AnalogOutNodeCarrier, c_bool(True))
dwf.FDwfAnalogOutNodeFunctionSet(hdwf, channel2, AnalogOutNodeCarrier, funcSine)
dwf.FDwfAnalogOutNodeFrequencySet(hdwf, channel2, AnalogOutNodeCarrier, c_double(20000))
dwf.FDwfAnalogOutNodeAmplitudeSet(hdwf, channel2, AnalogOutNodeCarrier, c_double(1))
dwf.FDwfAnalogOutNodeOffsetSet(hdwf, channel2, AnalogOutNodeCarrier, c_double(1.41))

print ("Aquiring from each channel...")
dwf.FDwfAnalogInStatus
dwf.FDwfAnalogOutStatus


print ("Driving from each channel...")
dwf.FDwfDigitalIOStatus

print ("Generating the two sine waves for 10 seconds...")
fs1 = dwf.FDwfAnalogOutConfigure(hdwf, channel1, c_bool(True))
fs2=  dwf.FDwfAnalogOutConfigure(hdwf, channel2, c_bool(True))
time.sleep(10)
print ("Generating the Superimposed sine wave of the two sine waves for 10 seconds...")
fs_Superimposed = fs1 + fs2
time.sleep(10)
print ("done.")


# Band Pass filter functions on the Sinewaves
##def butter_bandpass(lowcut, highcut, fs_Superimposed, order=5):
##    nyq = 0.5 * fs_Superimposed
##    low = lowcut / nyq
##    high = highcut / nyq
##    sos = butter(order, [low, high], analog=False, btype='band', output='sos')
##    return sos
##
##
##def butter_bandpass_filter(data, lowcut, highcut, fs_Superimposed, order=5):
##    sos = butter_bandpass(lowcut, highcut, fs_Superimposed, order=order)
##    y = sosfilt(sos, data)
##    return y
##
##
##if __name__ == "__main__":
##    import numpy as np
##    import matplotlib.pyplot as plt
##    from scipy.signal import freqz
##
##    # Sample rate and desired cutoff frequencies (in Hz).
##    fs_Superimposed = fs_Superimposed*1000  # change the filter_design.py in scipy "Digital and Valueerror and change 5000 to fs_Superimposed
####    fs = fs_Superimposed
##    lowcut = 500.0*1000
##    highcut = 1250.0*1000
##
##    # Plot the frequency response for a few different orders.
##    plt.figure(1)
##    plt.clf()
##    for order in [3, 6, 9]:
##        sos = butter_bandpass(lowcut, highcut, fs_Superimposed, order=order)
##        w, h = sosfreqz(sos, worN=2000)
##        plt.plot((fs_Superimposed/1000 * 0.5 / np.pi) * w, abs(h), label="order = %d" % order)
##
##    plt.plot([0, 0.5 * fs_Superimposed/1000], [np.sqrt(0.5), np.sqrt(0.5)],
##             '--', label='sqrt(0.5)')
##    plt.xlabel('Frequency (kHz)')
##    plt.ylabel('Gain')
##    plt.grid(True)
##    plt.legend(loc='best')
##
##    # Filter a noisy signal.
##    T = 0.01
##    nsamples = T * fs_Superimposed
##    t = np.linspace(0, T, nsamples, endpoint=False)
##    a = 0.02
##    f0 = 600.0*1000
##    x = 0.1 * np.sin(2 * np.pi * 1.2 * np.sqrt(t))
##    x += 0.01 * np.cos(2 * np.pi * 312 * t + 0.1)
##    x += a * np.cos(2 * np.pi * f0 * t + .11)
##    x += 0.03 * np.cos(2 * np.pi * 2000 * t)
##    plt.figure(2)
##    plt.clf()
##    plt.plot(t, x, label='Noisy signal')
##
##    y = butter_bandpass_filter(x, lowcut, highcut, fs_Superimposed, order=6)
##    plt.plot(t, y, label='Filtered signal (%g Hz)' % f0)
##    plt.xlabel('time (seconds)')
##    plt.hlines([-a, a], 0, T, linestyles='--')
##    plt.grid(True)
##    plt.axis('tight')
##    plt.legend(loc='upper left')
##
##    plt.margins(x=0, y=-0.25)
##       
##    plt.show()


#Aquisition and Reading of the Generated Samples and Signals of the two channels
    
print ("Preparing to read sample...")

#set up acquisition
dwf.FDwfAnalogInFrequencySet(hdwf, c_double(20000000.0))
dwf.FDwfAnalogInBufferSizeSet(hdwf, c_int(4000)) 
dwf.FDwfAnalogInChannelEnableSet(hdwf, c_int(0), c_bool(True))
dwf.FDwfAnalogInChannelRangeSet(hdwf, c_int(0), c_double(5))

#wait at least 2 seconds for the offset to stabilize
time.sleep(2)

#begin acquisition
dwf.FDwfAnalogInConfigure(hdwf, c_bool(False), c_bool(True))
print ("   waiting to finish")

while True:
    dwf.FDwfAnalogInStatus(hdwf, c_int(1), byref(sts))
    print ("STS VAL: " + str(sts.value) + "STS DONE: " + str(DwfStateDone.value))
    if sts.value == DwfStateDone.value: 
        break
    time.sleep(0.1)
print ("Acquisition finished")

dwf.FDwfAnalogInStatusData(hdwf, 0, rgdSamples, 4000) # get channel 1 data
dwf.FDwfAnalogInStatusData(hdwf, 1, rgdSamples, 4000) # get channel 2 data
dwf.FDwfDeviceCloseAll()

#plot window
dc = sum(rgdSamples)/len(rgdSamples)
print ("DC: "+str(dc)+"V")

rgpy=[0.0]*len(rgdSamples)
superimposed=fs_Superimposed*[0.0]*len(rgdSamples)

for i in range(0,len(rgpy)):
    rgpy[i]=rgdSamples[i]

plt.plot(rgpy)
plt.show()

#Superimposed_Signal Reading and Ploting
for r in range(fs_Superimposed*10000,len(superimposed)):
    superimposed[r]=rgdSamples[r]

plt.plot(superimposed)
plt.show()

# Impedance function for measuring the resultant impedance of the Signals
def impedance(circuit, omega):
    def r(x):
        return x
    def l(x):
        return complex(fs_Superimposed, omega * x)
    def c(x):
        return complex(fs_Superimposed, -1.0 / (omega * x))
    return eval(circuit)
def series(*things):
    return sum(things)
def parallel(*things):
    return 1. / (sum(1. / value for value in things))
if __name__ == '__main__':
    # definition in pairs from LISP implementation
    ##circuit_a = 'series(r(1), parallel(series(r(100.0),l(0.2)), parallel(c(1e-06),r(1000000.0))))'
    # This implementation knows to deal with more than two components in serial/parallel
    circuit_a = 'series(r(1), parallel(series(r(100.0),l(0.2)), c(1e-06),r(1000000.0)))'
    print(circuit_a)
    for omega in 2179.44, 2207.99:
        p = impedance(circuit_a, omega)
        print('omega = %.2f' % omega)
        print(u'rectangular: %.2f + %.2fj' % (p.real, p.imag))
        print(u'polar, angle in degrees: %.2f Î©, Ï† = %.2f Â°' % (abs(p), degrees(phase(p))))
        print('-'*60)
    plt.plot([p,p.real,p.imag,omega])
    plt.xlabel('Impedance (kOhms)') 
    plt.ylabel('Frequency (kHZ)')
    plt.show() 

def impedance2(circuit, frequency):
    frequency = fs_Superimposed
    w = frequency*2*math.pi
    return w
    for frequency in 1000, 20000000:
     imp = impedance2(circuit_a, frequency)
    plt.plot (imp, frequency)
    plt.xlabel('Impedance (kOhms)') 
    plt.ylabel('Frequency (HZ)')
    plt.show()
    
# Finishing and Closing the digilent device


dwf.FDwfDeviceClose(hdwf)
    
