#Analog sine imports
from ctypes import *
import time
from dwfconstants import *
import sys
import matplotlib.pyplot as plt
#Impedance Function Imports
from math import pi, degrees
from cmath import phase
import matplotlib.pyplot as plt
import math
#skrf phase and impedance plotting
import matplotlib
import skrf as rf
rf.stylely()

if sys.platform.startswith("win"):
    dwf = cdll.dwf
elif sys.platform.startswith("darwin"):
    dwf = cdll.LoadLibrary("/Library/Frameworks/dwf.framework/dwf")
else:
    dwf = cdll.LoadLibrary("libdwf.so")


#declaring variables
hdwf = c_int()
sts = c_byte()
IsEnabled = c_bool()
usbVoltage = c_double()
usbCurrent = c_double()
auxVoltage = c_double()
auxCurrent = c_double()
supplyVoltage = c_double()
supplyCurrent = c_double()
supplyPower = c_double()
supplyLoadPercentage = c_double()
channel1 = c_int(0)
channel2 = c_int(0)
rgdSamples = (c_double*4000)()


#print DWF version
version = create_string_buffer(16)
dwf.FDwfGetVersion(version)
print ("DWF Version:")

#opening the digilent device
print ("Opening first digilent device")
dwf.FDwfDeviceOpen(c_int(-1), byref(hdwf))

if hdwf.value == hdwfNone.value:
    print ("failed to open device")
    quit()



# Generating Sine Waveforms Signals on the two channels
print ("Generating sine wave for channel 1...")
dwf.FDwfAnalogOutNodeEnableSet(hdwf, channel1, AnalogOutNodeCarrier, c_bool(True))
dwf.FDwfAnalogOutNodeFunctionSet(hdwf, channel1, AnalogOutNodeCarrier, funcSine)
dwf.FDwfAnalogOutNodeFrequencySet(hdwf, channel1, AnalogOutNodeCarrier, c_double(500000))
dwf.FDwfAnalogOutNodeAmplitudeSet(hdwf, channel1, AnalogOutNodeCarrier, c_double(1))
dwf.FDwfAnalogOutNodeOffsetSet(hdwf, channel1, AnalogOutNodeCarrier, c_double(0))
fs1 = dwf.FDwfAnalogOutConfigure(hdwf, channel1, c_bool(True))

print ("Generating sine wave for channel 2...") #channel 1
dwf.FDwfAnalogOutNodeEnableSet(hdwf, channel1, AnalogOutNodeCarrier, c_bool(True))
dwf.FDwfAnalogOutNodeFunctionSet(hdwf, channel1, AnalogOutNodeCarrier, funcSine)
dwf.FDwfAnalogOutNodeFrequencySet(hdwf, channel1, AnalogOutNodeCarrier, c_double(1000000))
dwf.FDwfAnalogOutNodeAmplitudeSet(hdwf, channel1, AnalogOutNodeCarrier, c_double(1))
dwf.FDwfAnalogOutNodeOffsetSet(hdwf, channel1, AnalogOutNodeCarrier, c_double(0))
fs2=  dwf.FDwfAnalogOutConfigure(hdwf, channel1, c_bool(True))

print ("Generating the Superimposed sine wave again of the two sine waves for 50 seconds...")
fs_Superimposed = fs1 + fs2
#fs_superimposed set to out of channel 1
dwf.FDwfAnalogOutNodeEnableSet(hdwf, channel1, AnalogOutNodeCarrier, c_bool(True))
dwf.FDwfAnalogOutNodeFunctionSet(hdwf, channel1, AnalogOutNodeCarrier, funcSine)
dwf.FDwfAnalogOutNodeFrequencySet(hdwf, channel1, AnalogOutNodeCarrier, c_double(1000000+500000))
dwf.FDwfAnalogOutNodeAmplitudeSet(hdwf, channel1, AnalogOutNodeCarrier, c_double(1))
dwf.FDwfAnalogOutNodeOffsetSet(hdwf, channel1, AnalogOutNodeCarrier, c_double(0))
#fs_Superimposed = dwf.FDwfAnalogOutConfigure(hdwf, channel1, c_bool(True)) #
fs_Superimposed = fs1 + fs2
time.sleep(5)
print ("done.")








def impedance(circuit, omega):
    def r(x):
        return x
    def l(x):
        return complex(fs_Superimposed, omega * x)
    def c(x):
        return complex(fs_Superimposed, -1.0 / (omega * x))
    return eval(circuit)
def series(*things):
    return sum(things)
def parallel(*things):
    return 1. / (sum(1. / value for value in things))
if __name__ == '__main__':
    # definition in pairs from LISP implementation
    ##circuit_a = 'series(r(1), parallel(series(r(100.0),l(0.2)), parallel(c(1e-06),r(1000000.0))))'
    # This implementation knows to deal with more than two components in serial/parallel
    circuit_a = 'series(r(1), parallel(series(r(100.0),l(0.2)), c(1e-06),r(1000000.0)))'
    print(circuit_a)
    for omega in 2179.44, 2207.99:
        p = impedance(circuit_a, omega)
        print('omega = %.2f' % omega)
        print(u'rectangular: %.2f + %.2fj' % (p.real, p.imag))
        print(u'polar, angle in degrees: %.2f Î©, Ï† = %.2f Â°' % (abs(p), degrees(phase(p))))
        print('-'*60)
    plt.plot([p,p.real,p.imag,omega])
    plt.xlabel('Frequency (kHz)') 
    plt.ylabel('Impedance (kOhms)')
    plt.show()


def impedance1(circuit, omega):
    def r(x):
        return x
    def l(x):
        return complex(fs1, omega * x)
    def c(x):
        return complex(fs1, -1.0 / (omega * x))
    return eval(circuit)
def series(*things):
    return sum(things)
def parallel(*things):
    return 1. / (sum(1. / value for value in things))
if __name__ == '__main__':
    # definition in pairs from LISP implementation
    ##circuit_a = 'series(r(1), parallel(series(r(100.0),l(0.2)), parallel(c(1e-06),r(1000000.0))))'
    # This implementation knows to deal with more than two components in serial/parallel
    circuit_a = 'series(r(1), parallel(series(r(100.0),l(0.2)), c(1e-06),r(1000000.0)))'
    print(circuit_a)
    for omega in 2179.44, 2207.99:
        p = impedance(circuit_a, omega)
        print('omega = %.2f' % omega)
        print(u'rectangular: %.2f + %.2fj' % (p.real, p.imag))
        print(u'polar, angle in degrees: %.2f Î©, Ï† = %.2f Â°' % (abs(p), degrees(phase(p))))
        print('-'*60)
    plt.plot([p,p.real,p.imag,omega])
    plt.xlabel('R') 
    plt.ylabel('X')
    plt.show() 

def impedance2(circuit, omega):
    def r(x):
        return x
    def l(x):
        return complex(fs2, omega * x)
    def c(x):
        return complex(fs2, -1.0 / (omega * x))
    return eval(circuit)
def series(*things):
    return sum(things)
def parallel(*things):
    return 1. / (sum(1. / value for value in things))
if __name__ == '__main__':
    # definition in pairs from LISP implementation
    ##circuit_a = 'series(r(1), parallel(series(r(100.0),l(0.2)), parallel(c(1e-06),r(1000000.0))))'
    # This implementation knows to deal with more than two components in serial/parallel
    circuit_a = 'series(r(1), parallel(series(r(100.0),l(0.2)), c(1e-06),r(1000000.0)))'
    print(circuit_a)
    for omega in 2179.44, 2207.99:
        p = impedance(circuit_a, omega)
        print('omega = %.2f' % omega)
        print(u'rectangular: %.2f + %.2fj' % (p.real, p.imag))
        print(u'polar, angle in degrees: %.2f Î©, Ï† = %.2f Â°' % (abs(p), degrees(phase(p))))
        print('-'*60)
##        s2 =  (p,fs2)
    plt.plot([p,p.real,p.imag,omega])
    plt.xlabel('Impedance (kOhms)') 
    plt.ylabel('Frequency (kHz)')
##    rf.Network(plot_s_deg())
##    rf.Network(plot_z_im())
    plt.show() 
##    plt.plot([s2,p.real,p.imag,omega])
##    plt.xlabel('Rs2') 
##    plt.ylabel('Xs2')
##    plt.show() 
##    

##def impedance3(circuit, frequency):
##     def r(x):
##        f = fs1
##        c = 33
##        x = 1/(2*math.pi*f*c)
##        return x
##    
##for frequency in 1000, 20000000:
##    imp = impedance2(circuit_a, fs1)
##    plt.plot (imp, frequency)
##    plt.xlabel('R ') 
##    plt.ylabel('X ')
##    plt.show()


#The following is the Impedance function where C is the Capacitance, Freq is the total Frequency of the signal and R is the Resistance
def ImpedancewithCap(C,Freq,R):    
    X = 1/(2*math.pi*C*Freq)
    
    Z = math.sqrt (X ** 2 + R ** 2)
    return Z
    

##print ("Impedance is: " + str(ImpedancewithCap(33e-12,fs1)/1000000)+ " Ohms") 
print ("Impedance is: " + str(ImpedancewithCap(33e-12,fs1,1000)/1000000)+ " Ohms") #the Frequency signal can be changed Or Specify the frequency in number
##R = 1000
##Z = ImpedancewithCap(33e-12,fs1,1000)
##X2 = 1/(2*math.pi*33e-12*1000000)
##plt.plot (X2,1000)
##plt.xlabel('R (Real Resistor Value) Ohms') 
##plt.ylabel('X (Imaginery Impendace Equation Value) kHz')
##plt.show()
    
# Finishing and Closing the digilent device


dwf.FDwfDeviceClose(hdwf)
    
